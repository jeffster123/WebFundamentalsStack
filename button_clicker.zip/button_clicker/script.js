function hide (element) {
    element.remove();
}

function login (element) {
    element.innerText = "Logout";
}

function like () {
    alert("Ninja was liked");
}